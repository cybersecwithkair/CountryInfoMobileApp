package edu.monash.fit2081.countryinfo;

public class countryName {
}
