package edu.monash.fit2081.countryinfo;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HttpsURLConnection;

public class CountryDetails extends AppCompatActivity {

    private TextView name;
    private TextView capital;
    private TextView code;
    private TextView population;
    private TextView area;
    private TextView currencies;
    private TextView languages;
    private ImageView flagView;
    private Button wikiButton;
    private String countryName;
    private TextView airlines;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_details);

        getSupportActionBar().setTitle(R.string.title_activity_country_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final String selectedCountry = getIntent().getStringExtra("country");

        countryName = selectedCountry ;

        name = findViewById(R.id.country_name);
        capital = findViewById(R.id.capital);
        code = findViewById(R.id.country_code);
        population = findViewById(R.id.population);
        area = findViewById(R.id.area);
        currencies = findViewById(R.id.currencies);
        languages = findViewById(R.id.languages);
        flagView = findViewById(R.id.imageView);
        wikiButton = findViewById(R.id.buttonWiki);
        airlines = findViewById(R.id.airlines);


        ExecutorService executor = Executors.newSingleThreadExecutor();
        //Executor handler = ContextCompat.getMainExecutor(this);
        Handler uiHandler = new Handler(Looper.getMainLooper());


        executor.execute(() -> {
            //Background work here
            CountryInfo countryInfo = new CountryInfo();

            try {
                // Create URL
                URL webServiceEndPoint = new URL("https://restcountries.com/v2/name/" + selectedCountry); //

                // Create connection
                HttpsURLConnection myConnection = (HttpsURLConnection) webServiceEndPoint.openConnection();

                if (myConnection.getResponseCode() == 200) {
                    //JSON data has arrived successfully, now we need to open a stream to it and get a reader
                    InputStream responseBody = myConnection.getInputStream();
                    InputStreamReader responseBodyReader = new InputStreamReader(responseBody, "UTF-8");

                    //now use a JSON parser to decode data
                    JsonReader jsonReader = new JsonReader(responseBodyReader);
                    jsonReader.beginArray(); //consume arrays's opening JSON brace
                    String keyName;
                    // countryInfo = new CountryInfo(); //nested class (see below) to carry Country Data around in
                    boolean countryFound = false;
                    while (jsonReader.hasNext() && !countryFound) { //process array of objects
                        jsonReader.beginObject(); //consume object's opening JSON brace
                        while (jsonReader.hasNext()) {// process key/value pairs inside the current object
                            keyName = jsonReader.nextName();
                            if (keyName.equals("name")) {
                                countryInfo.setName(jsonReader.nextString());
                                if (countryInfo.getName().equalsIgnoreCase(selectedCountry)) {
                                    countryFound = true;
                                }

                            } else if (keyName.equals("alpha3Code")) {
                                countryInfo.setAlpha3Code(jsonReader.nextString());
                            } else if (keyName.equals("capital")) {
                                countryInfo.setCapital(jsonReader.nextString());
                            } else if (keyName.equals("population")) {
                                countryInfo.setPopulation(jsonReader.nextInt());
                            } else if (keyName.equals("area")) {
                                countryInfo.setArea(jsonReader.nextDouble());
                            } else if (keyName.equals("currencies")) {
                                jsonReader.beginArray();
                                while (jsonReader.hasNext()) {
                                    jsonReader.beginObject();
                                    while (jsonReader.hasNext()) {
                                        String nameToRead = jsonReader.nextName();
                                        if (nameToRead.equals("name")) {
                                            countryInfo.setCurrencies(jsonReader.nextString());
                                        } else {
                                            jsonReader.skipValue();
                                        }

                                    }
                                    jsonReader.endObject();
                                }
                                jsonReader.endArray();
                            } else if (keyName.equals("languages")) {
                                jsonReader.beginArray();
                                while (jsonReader.hasNext()) {
                                    jsonReader.beginObject();
                                    while (jsonReader.hasNext()) {
                                        String nameToRead = jsonReader.nextName();
                                        if (nameToRead.equals("name")) {
                                            countryInfo.setLanguages(jsonReader.nextString());
                                        } else {
                                            jsonReader.skipValue();
                                        }
                                    }

                                    jsonReader.endObject();
                                }
                                jsonReader.endArray();

                            } else {
                                jsonReader.skipValue();
                            }
                        }
                        jsonReader.endObject();
                    }
                    jsonReader.endArray();
                    uiHandler.post(() -> {
                        Glide.with(this).load("https://countryflagsapi.com/png/"+ countryInfo.alpha3Code).into(flagView);
                        name.setText(countryInfo.getName());
                        capital.setText(countryInfo.getCapital());
                        code.setText(countryInfo.getAlpha3Code());
                        population.setText(Integer.toString(countryInfo.getPopulation()));
                        area.setText(Double.toString(countryInfo.getArea()));
                        currencies.setText(countryInfo.getCurrencies());
                        languages.setText(countryInfo.getLanguages());
                        wikiButton.setText("WIKI "+ countryInfo.getName().toString().toUpperCase());

                    });


                } else {
                    Log.i("INFO", "Error:  No response");
                }

                // All your networking logic should be here
            } catch (Exception e) {
                Log.i("INFO", "Error " + e.toString());
            }

            try {
                // Create URL

                URL webServiceEndPoint = new URL("https://airlabs.co/api/v9/airlines?api_key=3908e30b-edaf-43f4-a492-29c4ed458a23&country_code" + countryInfo.alpha3Code); //

                // Create connection
                HttpsURLConnection myConnection = (HttpsURLConnection) webServiceEndPoint.openConnection();

                if (myConnection.getResponseCode() == 200) {
                    //JSON data has arrived successfully, now we need to open a stream to it and get a reader
                    InputStream responseBody = myConnection.getInputStream();
                    InputStreamReader responseBodyReader = new InputStreamReader(responseBody, "UTF-8");
                    JsonReader jsonReader = new JsonReader(responseBodyReader);
                    jsonReader.beginArray();
                    while (jsonReader.hasNext()){
                        jsonReader.beginObject();
                        while (jsonReader.hasNext()){
                            String air = jsonReader.nextName();
                            if(air.equals("name")) {
                                JSONObject object = new JSONObject("https://airlabs.co/api/v9/airlines?api_key=3908e30b-edaf-43f4-a492-29c4ed458a23&country_code");
                                JSONObject getObject = object.getJSONObject("response");
                                for (int i = 0; i < getObject.length(); i++) {
                                    JSONObject objects = getObject.getJSONObject(String.valueOf(i));

                                }
                                countryInfo.setAirlines(jsonReader.nextString());
                            } else {
                                jsonReader.skipValue();

                            }
                            jsonReader.endObject();
                        }
                        uiHandler.post(() -> {
                            airlines.setText(countryInfo.getAirlines());

                        });

                    } jsonReader.endArray();
                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

        });



    }


    public void OnClick(View view) {
//        WebWiki webWiki = new WebWiki();
//        webWiki.setCountryDetails(this);
        Intent wiki = new Intent(this,WebWiki.class);
        wiki.putExtra("COUNTRY",countryName);

        startActivity(wiki);
    }



    private class CountryInfo {
        private String name;
        private String alpha3Code;
        private String capital;
        private int population;
        private double area;
        private String currencies;
        private String languages;
        private String airlines;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAlpha3Code() {
            return alpha3Code;
        }

        public void setAlpha3Code(String alpha3Code) {
            this.alpha3Code = alpha3Code;
        }

        public String getCapital() {
            return capital;
        }

        public void setCapital(String capital) {
            this.capital = capital;
        }

        public int getPopulation() {
            return population;
        }

        public void setPopulation(int population) {
            this.population = population;
        }

        public double getArea() {
            return area;
        }

        public void setArea(double area) {
            this.area = area;
        }

        public String getCurrencies() {
            return currencies;
        }

        public void setCurrencies(String currencies) {
            this.currencies = currencies;
        }

        public String getLanguages() {
            return languages;
        }

        public void setLanguages(String languages) {
            this.languages = languages;
        }

        public String getAirlines() {
            return airlines;
        }

        public void setAirlines(String airlines) {
            this.airlines = airlines;
        }

    }
}

