package edu.monash.fit2081.countryinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebWiki extends AppCompatActivity {

    public void setCountryDetails(CountryDetails countryDetails) {
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_wiki);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        WebView wiki = findViewById(R.id.webView);
        wiki.setWebViewClient(new WebViewClient());
        wiki.loadUrl("https://en.wikipedia.org/wiki/"+this.getIntent().getStringExtra("COUNTRY"));
    }


}





